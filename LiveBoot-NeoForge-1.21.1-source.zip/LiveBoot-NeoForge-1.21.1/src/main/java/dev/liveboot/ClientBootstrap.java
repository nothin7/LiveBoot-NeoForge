package dev.liveboot;

import dev.liveboot.logging.LiveBootLogAppender;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.LoggerContext;

/**
 * Installs after this mod is constructed. Earlier bootstrap messages are not
 * retroactively available through this appender.
 */
public final class ClientBootstrap {
    private ClientBootstrap() {}

    public static void install() {
        LoggerContext context = (LoggerContext) org.apache.logging.log4j.LogManager.getContext(false);
        var config = context.getConfiguration();
        LiveBootLogAppender appender = new LiveBootLogAppender();
        appender.start();
        config.getRootLogger().addAppender(appender, Level.ALL, null);
        context.updateLoggers();
        LiveBootLogStore.add("LiveBoot attached to the Minecraft logger", "INFO");
    }
}
