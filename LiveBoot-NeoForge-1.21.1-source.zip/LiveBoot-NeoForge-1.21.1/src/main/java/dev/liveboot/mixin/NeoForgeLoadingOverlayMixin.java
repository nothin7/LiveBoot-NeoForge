package dev.liveboot.mixin;

import dev.liveboot.logging.LiveBootLogStore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.neoforge.client.loading.NeoForgeLoadingOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Replaces the NeoForge early loading overlay render with a simple log view.
 * Kept deliberately conservative: only rendering is replaced; loading itself
 * remains owned by NeoForge.
 */
@Mixin(NeoForgeLoadingOverlay.class)
public abstract class NeoForgeLoadingOverlayMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void liveboot$render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();

        graphics.fill(0, 0, width, height, 0xFF080B0A);
        graphics.fill(0, 0, width, 3, 0xFF35D07F);

        int left = 18;
        graphics.drawString(mc.font, "LIVEBOOT // NEOFORGE", left, 18, 0xFF35D07F, false);
        graphics.drawString(mc.font, "MINECRAFT 1.21.1  |  STARTUP CONSOLE", left, 32, 0xFF8B9690, false);
        graphics.fill(left, 48, width - left, 49, 0xFF26332C);

        List<LiveBootLogStore.Entry> entries = LiveBootLogStore.snapshot();
        int lineHeight = 10;
        int maxLines = Math.max(1, (height - 100) / lineHeight);
        int start = Math.max(0, entries.size() - maxLines);
        int y = 60;

        for (int i = start; i < entries.size(); i++) {
            var entry = entries.get(i);
            int color = switch (entry.level()) {
                case "ERROR", "FATAL" -> 0xFFFF6262;
                case "WARN" -> 0xFFFFD166;
                case "DEBUG", "TRACE" -> 0xFF84918A;
                default -> 0xFFE0E8E2;
            };
            String line = entry.time() + " [" + entry.level() + "] " + entry.message();
            int maxChars = Math.max(20, (width - 40) / 6);
            if (line.length() > maxChars) line = line.substring(0, maxChars - 1) + "…";
            graphics.drawString(mc.font, line, left, y, color, false);
            y += lineHeight;
        }

        graphics.fill(left, height - 30, width - left, height - 28, 0xFF26332C);
        graphics.fill(left, height - 30, left + Math.max(2, (int)((System.currentTimeMillis() / 25) % Math.max(1, width - left * 2))), height - 28, 0xFF35D07F);
        graphics.drawString(mc.font, "WAITING FOR GAME INITIALIZATION...", left, height - 20, 0xFF8B9690, false);

        ci.cancel();
    }
}
