package dev.liveboot.logging;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class LiveBootLogStore {
    public record Entry(String time, String level, String message) {}

    private static final int MAX_ENTRIES = 300;
    private static final ArrayDeque<Entry> ENTRIES = new ArrayDeque<>();

    private LiveBootLogStore() {}

    public static synchronized void add(String message, String level) {
        String time = java.time.LocalTime.now().withNano(0).toString();
        ENTRIES.addLast(new Entry(time, level, message));
        while (ENTRIES.size() > MAX_ENTRIES) ENTRIES.removeFirst();
    }

    public static synchronized List<Entry> snapshot() {
        return new ArrayList<>(ENTRIES);
    }
}
