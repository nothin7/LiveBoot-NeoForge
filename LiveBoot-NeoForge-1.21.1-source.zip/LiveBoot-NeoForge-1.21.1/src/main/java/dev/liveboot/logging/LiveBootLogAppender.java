package dev.liveboot.logging;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.Property;

public final class LiveBootLogAppender extends AbstractAppender {
    public LiveBootLogAppender() {
        super("LiveBootAppender", null, null, false, Property.EMPTY_ARRAY);
    }

    @Override
    public void append(LogEvent event) {
        String message = event.getMessage() == null ? "" : event.getMessage().getFormattedMessage();
        String logger = event.getLoggerName();
        if (logger != null && !logger.isBlank()) message = "[" + logger + "] " + message;
        LiveBootLogStore.add(message, event.getLevel().name());
    }
}
