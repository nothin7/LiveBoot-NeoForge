package dev.liveboot;

import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.api.distmarker.Dist;

@Mod(LiveBoot.MOD_ID)
public final class LiveBoot {
    public static final String MOD_ID = "liveboot";

    public LiveBoot() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientBootstrap.install();
        }
    }
}
